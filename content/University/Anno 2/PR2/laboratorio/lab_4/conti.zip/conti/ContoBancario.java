package it.unica.pr2.banca.conti;

public class ContoBancario{

	private String nome;
	private String cognome;
	private double saldo;
	private int numeroConto;
	private static int ultimoNumeroConto = 1000;


	public ContoBancario(){
		this.numeroConto = ultimoNumeroConto + 1;
		ultimoNumeroConto = this.numeroConto;
		this.nome = "default name";
		this.cognome = "default surname";
		this.saldo = 0;
	}

	public ContoBancario(String nome, String cognome, double saldo){
		this();
		this.nome = nome;
		this.cognome = cognome;
		this.saldo = saldo;
	}

	public ContoBancario(ContoBancario altroContoBancario){
		this();
		if (altroContoBancario != null){
			this.nome = altroContoBancario.getNome();
			this.cognome = altroContoBancario.getCognome();
			this.saldo = altroContoBancario.getSaldo();
			this.numeroConto = altroContoBancario.getNumeroConto();
		}
	}

	public String getNome(){
		return this.nome;
	}

	public String getCognome(){
		return this.cognome;
	}

	public double getSaldo(){
		return this.saldo;
	}

	public int getNumeroConto(){
		return this.numeroConto;
	}


	public void preleva (double importo) throws IllegalArgumentException, InsufficientFundsException{
		if (importo < 0){
			throw new IllegalArgumentException("Argomento non valido");
		}
		if (importo > this.saldo)		{
			throw new InsufficientFundsException("Non hai fondi sufficienti!");
		}
		this.saldo = this.saldo - importo;
	}



	public static double convertiInEuro(double dollari, double tassoConversione){
		return dollari * tassoConversione;
	}


	@Override
	public boolean equals(Object otherObject){
		if (this == otherObject){
			return true;
		}else if (otherObject == null){
			return false;
		}else if (otherObject.getClass() != getClass()){
			return false;
		}

		ContoBancario altroContoBancario = (ContoBancario) otherObject;
		
		return (this.nome.equals(altroContoBancario.nome)) &&
			   (this.cognome.equals(altroContoBancario.cognome)) &&
			   (this.saldo == altroContoBancario.saldo) &&
			   (this.numeroConto == altroContoBancario.numeroConto);
	}


}