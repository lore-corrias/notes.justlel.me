package it.unica.pr2.banca.conti;

public class ContoCorrente extends ContoBancario{

	private double rendimento;
	

	public ContoCorrente(){
		super();
		this.rendimento = 0.0;
	}

	public ContoCorrente(String nome, String cognome, double saldo, double rendimento){
		super(nome, cognome, saldo);
		this.rendimento = rendimento;
	}

	public ContoCorrente(ContoCorrente altroContoCorrente){
		super(altroContoCorrente);
		if (altroContoCorrente != null){
			this.rendimento = altroContoCorrente.getRendimento();
		}
	}

	public double getRendimento(){
		return this.rendimento;
	}


	@Override
	public boolean equals(Object otherObject){
		if (this == otherObject){
			return true;
		}else if (otherObject == null){
			return false;
		}else if (otherObject.getClass() != getClass()){
			return false;
		}else if(!super.equals(otherObject)){
			return false;
		}

		ContoCorrente altroContoCorrente = (ContoCorrente) otherObject;

		return (this.rendimento == altroContoCorrente.getRendimento());
	}


}